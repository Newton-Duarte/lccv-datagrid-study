# Theme

Customize grid styling through the modern AG Grid Theming API, inherited design tokens, or scoped CSS properties. Prerequisite: [standard grid setup](./standard-grid.md).

## Required styles and layout

Import `sbwb-ds-v2-aggrid/styles/theme.css` once; it includes design tokens and the wrapper/Spreadsheet extensions. Provide a parent with a non-zero height. `DataGrid` adds `.sbwb-data-grid` and your optional `className` to its outer wrapper.

The default theme extends Quartz with these token-backed parameters; other Quartz defaults remain available:

| Parameter               | Default token           |
| ----------------------- | ----------------------- |
| `accentColor`           | `--color-sky-500`       |
| `backgroundColor`       | `--color-white`         |
| `chromeBackgroundColor` | `--color-gray-50`       |
| `fontFamily`            | `--font-family-primary` |
| `foregroundColor`       | `--color-stone-900`     |
| `invalidColor`          | `--color-red-600`       |

Override inherited tokens on an application container, scoped `--ag-*` properties on your grid class, or pass a theme through `theme`. The internal default theme constant is not exported. Supplying a different theme replaces the default theme choice; configure its parameters explicitly.

Do not import legacy `ag-grid.css` or `ag-theme-quartz.css`, pass `theme="legacy"`, or require an `ag-theme-quartz` class. See the official [theme parameters](https://www.ag-grid.com/react-data-grid/theming-parameters/) and [CSS customization](https://www.ag-grid.com/react-data-grid/theming-css/) references for peer APIs.

## Complete example

This uses the same Quartz customization pattern as the working brand example. Copy both files and render `BrandGrid`.

### `brand-grid.tsx`

<!-- consumer-example: theme/brand-grid.tsx -->

```tsx
import { themeQuartz } from 'ag-grid-community'
import type { ColDef } from 'ag-grid-community'
import { DataGrid } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'
import './brand-grid.css'

type Row = { name: string; team: string }
const rows: Row[] = [
  { name: 'Ada', team: 'Platform' },
  { name: 'Grace', team: 'Infrastructure' },
]
const columns: ColDef<Row>[] = [{ field: 'name' }, { field: 'team' }]
const defaults: ColDef<Row> = { flex: 1, minWidth: 120, sortable: true, filter: true }
const customTheme = themeQuartz.withParams({
  accentColor: '#7c3aed',
  headerBackgroundColor: '#f3e8ff',
  fontFamily: 'var(--font-family-primary)',
})
export function BrandGrid() {
  return (
    <div className="brand-region" style={{ height: 300 }}>
      <DataGrid<Row>
        className="brand-grid"
        theme={customTheme}
        rowData={rows}
        columnDefs={columns}
        defaultColDef={defaults}
      />
    </div>
  )
}
```

### `brand-grid.css`

<!-- consumer-example: theme/brand-grid.css -->

```css
.brand-region {
  --font-family-primary: system-ui, sans-serif;
}
.brand-grid {
  --ag-range-selection-background-color: #ede9fe;
  --ag-range-selection-border-color: #7c3aed;
  --ag-range-selection-border-width: 1px;
  --ag-range-selection-border-style: solid;
}
```

The range variables customize this package's Spreadsheet selection, preview, and handles when using the same class with [Spreadsheet mode](./spreadsheet-mode.md). Setting them does not enable range interactions on a bare `DataGrid`. Token-only integrations can import `sbwb-ds-v2-aggrid/styles/tokens.css`; it does not replace the required theme stylesheet for the grid.

# Spreadsheet mode

Use `useSpreadsheet` to add cell ranges, clipboard operations, fill, bulk editing, and local undo/redo to the Community `DataGrid`. Begin with [installation](./standard-grid.md#install). This is the package's custom integration; no Enterprise module or `enableRangeSelection`/`cellSelection` setting is required.

## Ownership rules

- The application owns authoritative rows. `createImmutableDataAdapter` reads a versioned snapshot and publishes accepted batches synchronously.
- Keep the adapter and binding registration identity-stable for the hook's lifetime, including their reader/writer/parser/codec functions. Use constants, lazy state, or memoization. Changing the data owner or mapping requires a new keyed integration; the hook rejects ownership changes.
- Supply stable `getRowId` values and column IDs matching [column bindings](./column-bindings.md). The supported topology is displayed client-side body rows and bound columns. Pinned rows, group/footer rows, and server/infinite row models are outside Spreadsheet operation targets. Pinned columns are supported.
- Keep column schema and row-ID configuration stable during data edits. Normal row projections, editability, and callback updates remain supported.
- Publish the authoritative snapshot before scheduling React state. Pass the publication acknowledgment back to the hook with its projection so owned changes retain local history. A React render is a projection, not the synchronous source of truth.
- Attach `hostRef` to an enclosing DOM element and spread `spreadsheet.gridProps` onto `DataGrid`. The hook composes event handlers, renderers, and editor parameters. Avoid overwriting those composed props afterward.
- The hook forces `readOnlyEdit: true` so edit requests go through the adapter; explicitly setting it to false is an error. This does not make bound, editable cells read-only.
- AG Grid `valueParser` and `valueSetter` are not replayable substitutes for binding parsers and writers.

## Complete example

Copy both files into the same directory and render `ProjectGrid`. These adapt the working Project Quick Start. Bindings store `number | null` for budgets; two-decimal display formatting does not round the stored value.

### `project-data.ts`

<!-- consumer-example: spreadsheet/project-data.ts -->

```ts
import { createSpreadsheetNumberParser } from 'sbwb-ds-v2-aggrid'
import type { ColumnBinding } from 'sbwb-ds-v2-aggrid'
export type Project = {
  id: string
  name: string
  budget: number | null
}

export function createProjects(): Project[] {
  return [
    { id: 'project-1', name: 'Website', budget: 10000 },
    { id: 'project-2', name: 'Portal', budget: 20000 },
    { id: 'project-3', name: 'Reports', budget: null },
  ]
}
export const PROJECT_BINDINGS: readonly ColumnBinding<Project>[] = [
  {
    columnId: 'name',
    read: (row) => row.name,
    parse: ({ input }) => ({ ok: true, value: input == null ? '' : String(input) }),
    write: (row, value) => (typeof value === 'string' ? { ...row, name: value } : row),
  },
  {
    columnId: 'budget',
    read: (row) => row.budget,
    parse: createSpreadsheetNumberParser<Project>(),
    write: (row, value) =>
      value === null || (typeof value === 'number' && Number.isFinite(value))
        ? { ...row, budget: value }
        : row,
  },
]
```

### `project-grid.tsx`

<!-- consumer-example: spreadsheet/project-grid.tsx -->

```tsx
import { useMemo, useState } from 'react'
import type { KeyboardEvent } from 'react'
import type { ColDef } from 'ag-grid-community'
import {
  DataGrid,
  SpreadsheetTextEditor,
  SpreadsheetNumberEditor,
  createImmutableDataAdapter,
  useSpreadsheet,
} from 'sbwb-ds-v2-aggrid'
import type { DataAcknowledgment, DataSnapshot } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'
import { createProjects, PROJECT_BINDINGS } from './project-data.ts'
import type { Project } from './project-data.ts'

const budgetFormat = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
const columnDefs: ColDef<Project>[] = [
  {
    field: 'name',
    colId: 'name',
    editable: true,
    cellEditor: SpreadsheetTextEditor<Project>,
    cellEditorParams: { inputAriaLabel: 'Project name editor' },
  },
  {
    field: 'budget',
    colId: 'budget',
    editable: true,
    cellDataType: 'number',
    cellEditor: SpreadsheetNumberEditor<Project>,
    cellEditorParams: { inputAriaLabel: 'Budget editor' },
    valueFormatter: ({ value }) => (value == null ? '' : budgetFormat.format(value)),
  },
]
const defaultColDef: ColDef<Project> = { flex: 1, minWidth: 150, sortable: true, resizable: true }
const getRowId = ({ data }: { data: Project }) => data.id

// Application shortcut: focus a Spreadsheet handle from a non-editing grid cell.
function focusActiveHandle(event: KeyboardEvent<HTMLDivElement>) {
  if (!event.altKey || event.key.toLowerCase() !== 'h') return
  const target = event.target
  if (!(target instanceof HTMLElement)) return
  if (
    target.closest('[data-sbwb-handle], input, textarea, select, [contenteditable="true"]') ||
    !target.closest('.ag-cell')
  )
    return
  const handle = event.currentTarget.querySelector<HTMLButtonElement>('[data-sbwb-handle]')
  if (!handle) return
  event.preventDefault()
  handle.focus({ preventScroll: true })
}

export function ProjectGrid() {
  const [initial] = useState<DataSnapshot<Project>>(() => ({ version: 0, rows: createProjects() }))
  const [projection, setProjection] = useState<{
    snapshot: DataSnapshot<Project>
    acknowledgment?: DataAcknowledgment
  }>(() => ({ snapshot: initial }))
  const [feedback, setFeedback] = useState('Ready')
  const [data] = useState(() => {
    let snapshot = initial
    return createImmutableDataAdapter<Project>({
      bindings: PROJECT_BINDINGS,
      getRowId: (row) => row.id,
      getSnapshot: () => snapshot,
      publish: (next, acknowledgment) => {
        snapshot = next // Authoritative state changes synchronously, before returning.
        setProjection({ snapshot: next, acknowledgment })
      },
    })
  })
  const rowData = useMemo(
    () => projection.snapshot.rows.map((row) => ({ ...row })),
    [projection.snapshot],
  )
  const spreadsheet = useSpreadsheet({
    data,
    bindings: PROJECT_BINDINGS,
    acknowledgment: projection.acknowledgment,
    gridProps: { rowData, columnDefs, defaultColDef, getRowId },
    onResult: (result) =>
      setFeedback(
        result.rejected[0]?.message ??
          (result.rejected.length ? 'Some cells were rejected.' : 'Changes applied.'),
      ),
    onError: (error) => setFeedback(error instanceof Error ? error.message : String(error)),
  })
  return (
    <>
      <div
        ref={spreadsheet.hostRef}
        style={{ height: '22rem', width: '100%' }}
        onKeyDown={focusActiveHandle}
        aria-keyshortcuts="Alt+H"
      >
        <DataGrid<Project> {...spreadsheet.gridProps} />
      </div>
      <p role="status" aria-live="polite">
        {feedback}
      </p>
    </>
  )
}
```

## Selection and handles

| Interaction                         | Behavior                                                        |
| ----------------------------------- | --------------------------------------------------------------- |
| Drag body cells                     | Replace the selected rectangular range.                         |
| Ctrl/⌘-drag from an unselected cell | Add a range.                                                    |
| Ctrl/⌘-drag from a selected cell    | Subtract from the selection.                                    |
| Shift-click or Shift+Arrow          | Extend from the active anchor.                                  |
| Ctrl/⌘+A outside editors            | Select the displayed Spreadsheet topology.                      |
| `handleMode: 'fill'` (default)      | Preview and commit repeated values or simple numeric sequences. |
| `handleMode: 'range'`               | Resize the selection without writes.                            |
| `handleMode: 'none'`                | Hide the terminal handle.                                       |

The example's Alt+H handler is application code that focuses the active handle. Once focused, arrows preview a resize/fill, Enter applies it, and Escape cancels it. Fill uses each destination's parser and editability; rejected destinations retain their previous values. `handleLabels` and `selectionSummary` customize accessible labels/announcements. Read selection through `getSelection()` or subscribe via `subscribeSelection()`; for React rendering use `useSyncExternalStore` with the exposed selection store.

## Clipboard

- Ctrl/⌘+C exports a focused cell when no range is selected, otherwise selected ranges as tab/newline-separated text.
- `copySelectedRows: true` exports whole bound rows covered by selected cell ranges. It does not read independent AG Grid row selection. This option also expands Cut: after the clipboard write succeeds, Cut clears accepted writable cells across every displayed bound column in those covered rows. Selecting only a project name can therefore also clear its budget.
- Ctrl/⌘+V applies incoming text within the destination selection rectangle (or focused cell fallback). Select the intended destination size; paste does not append rows.
- Ctrl/⌘+X clears accepted source cells only after the clipboard write succeeds. A denied write reports an error and leaves values unchanged.
- Delete/Backspace clears values through bindings without removing rows. In this example names become empty strings and budgets become `null`.
- `formatCell(address, value)` overrides outbound text. It is independent of display `valueFormatter`; inbound conversion uses destination binding parsers.
- With the standard numeric parser, default numeric exports are lossless, ungrouped text in its locale. Matching-locale destinations round-trip; cross-locale paste does not guess the source locale.
- Browser clipboard writes require supported clipboard access and permission. `writeText` can provide a consumer implementation; `onError` reports write failures. While an input owns focus, native text clipboard behavior remains available.

## Editing and history

Set `editable` in column definitions and choose the supplied text/number editors to register raw drafts for bulk editing. Ordinary inline edit requests enter the runner as already-parsed values. The supplied number editor invokes its binding parser before emitting a value; custom editors must emit the stored value they intend to commit. Double-click or F2 opens an editor; Enter commits and Escape cancels. Ctrl/⌘+Enter applies a registered draft to selected writable cells, parsing each destination separately. Custom editors can register their own raw draft bridge; see the [API](./api-reference.md#editordraftbridge).

Outside editors, Ctrl/⌘+Z undoes and Ctrl/⌘+Y or Ctrl/⌘+Shift+Z redoes accepted operations. Paste/fill/bulk batches each replay as one command. Native text undo remains with active editors. New writes after undo discard redo history.

Configure `history: { maxCommands, maxBytes }`; defaults are 100 commands and 5,242,880 bytes. Selection/topology changes such as sorting/filtering or schema changes can invalidate history. External data replacement is not an owned acknowledgment: advance the application's data version and call `controller.synchronize()` to invalidate stale operations. A full source/binding change requires remounting with a new `key`.

`onResult` receives accepted changes and per-cell rejections; normal batches may partially succeed. Undo/redo conflicts or invalid replay invalidate history rather than replay a partial command. Errors in history or clipboard handling go to `onError`. The [API reference](./api-reference.md#spreadsheetcontroller) lists controller methods and options.

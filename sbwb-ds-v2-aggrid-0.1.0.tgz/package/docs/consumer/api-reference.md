# API reference

All components, hooks, helpers, and public types below are imported from `sbwb-ds-v2-aggrid`. Required stylesheet: `sbwb-ds-v2-aggrid/styles/theme.css`. AG Grid types/themes and React types come from their peer packages. Only Community features are supported.

The wrapper inherits Community `AgGridReactProps`; this reference lists the package's own contracts rather than reproducing the whole peer API. See [standard setup](./standard-grid.md), [columns](./column-definitions.md), [Spreadsheet setup](./spreadsheet-mode.md), and [RHF integration](./react-hook-form.md).

## Structural notation

The following local aliases keep the signatures readable. They describe nested structures and are **not package exports**. In application code, derive them from public types, for example `SelectionSnapshot['ranges'][number]`, `NonNullable<SpreadsheetViewport['getBounds']>`, or `Parameters<SpreadsheetController['registerCommand']>[1]`; do not import these alias names from the package. Signatures also use React and AG Grid peer types (`JSX.Element`, `ReactNode`, `ReactElement`, `ComponentPropsWithoutRef`, `AgGridReactProps`, `ICellRendererParams`, `CustomCellEditorProps`).

```ts
type RangeShape = {
  id: string
  rowStart: number
  rowEnd: number
  readonly columnIds: readonly string[]
}
type ViewportRect = { left: number; top: number; right: number; bottom: number }
type ShortcutAction =
  | { type: 'extend'; direction: 'up' | 'down' | 'left' | 'right' | 'all'; jump: boolean }
  | { type: 'clear' | 'undo' | 'redo' | 'bulk' }
type ShortcutEvent = Pick<
  KeyboardEvent,
  | 'key'
  | 'shiftKey'
  | 'ctrlKey'
  | 'metaKey'
  | 'altKey'
  | 'isComposing'
  | 'defaultPrevented'
  | 'preventDefault'
> & { altGraphKey?: boolean; getModifierState?: (keyArg: string) => boolean }
```

## Public export inventory

- **Grid wrapper:** [DataGrid](#datagrid), [DataGridProps](#datagridprops).
- **Spreadsheet setup and control:** [useSpreadsheet](#usespreadsheet), [SpreadsheetOptions](#spreadsheetoptions), [SpreadsheetBinding](#spreadsheetbinding), [SpreadsheetController](#spreadsheetcontroller), [SpreadsheetViewport](#spreadsheetviewport), [SpreadsheetHandleMode](#spreadsheethandlemode), [SpreadsheetHandleLabels](#spreadsheethandlelabels), [SpreadsheetHandlePointerInput](#spreadsheethandlepointerinput), [SpreadsheetCellState](#spreadsheetcellstate).
- **Renderers and editors:** [SpreadsheetCellRenderer](#spreadsheetcellrenderer), [SpreadsheetCellRendererParams](#spreadsheetcellrendererparams), [SpreadsheetCell](#spreadsheetcell), [SpreadsheetCellProps](#spreadsheetcellprops), [SpreadsheetTextEditor](#spreadsheettexteditor), [SpreadsheetTextEditorParams](#spreadsheettexteditorparams), [SpreadsheetTextEditorProps](#spreadsheettexteditorprops), [SpreadsheetNumberEditor](#spreadsheetnumbereditor), [SpreadsheetNumberEditorParams](#spreadsheetnumbereditorparams), [SpreadsheetNumberEditorProps](#spreadsheetnumbereditorprops), [createSpreadsheetNumberParser](#createspreadsheetnumberparser), [SpreadsheetNumberLocale](#spreadsheetnumberlocale), [SpreadsheetNumberParser](#spreadsheetnumberparser), [SpreadsheetNumberParserOptions](#spreadsheetnumberparseroptions).
- **Data ownership and bindings:** [createImmutableDataAdapter](#createimmutabledataadapter), [ImmutableDataAdapterOptions](#immutabledataadapteroptions), [SpreadsheetDataAdapter](#spreadsheetdataadapter), [DataSnapshot](#datasnapshot), [DataAcknowledgment](#dataacknowledgment), [ColumnBinding](#columnbinding), [ValueCodec](#valuecodec), [ParseInput](#parseinput), [ParseResult](#parseresult).
- **Operations and results:** [CellAddress](#celladdress), [CellPosition](#cellposition), [CellChange](#cellchange), [ChangeSource](#changesource), [ChangeBatch](#changebatch), [CommitResult](#commitresult), [OperationResult](#operationresult), [RejectedCell](#rejectedcell), [RejectionReason](#rejectionreason), [CandidateCell](#candidatecell), [OperationInput](#operationinput), [OperationMode](#operationmode), [OperationRunner](#operationrunner).
- **Selection and editor contracts:** [SelectionSnapshot](#selectionsnapshot), [SelectionAction](#selectionaction), [SelectionStore](#selectionstore), [SpreadsheetTopology](#spreadsheettopology), [TopologyChange](#topologychange), [EditorDraftBridge](#editordraftbridge), [ActiveEditor](#activeeditor), [EditorRegistry](#editorregistry).

## Grid wrapper

### `DataGrid`

Renders the Community adapter inside `.sbwb-data-grid`; defaults to all Community modules, a token-backed Quartz theme, and pt-BR labels. Additional `modules` are appended to Community modules. Consumers own rows, columns, callbacks, and parent height. See [setup](./standard-grid.md), [Theme](./theme.md), and [Locale](./locale.md).

```ts
function DataGrid<TData = unknown>(props: DataGridProps<TData>): JSX.Element
```

### `DataGridProps`

All inherited props retain their AG Grid Community meaning. `className` targets the outer wrapper. There is no wrapper-specific data source, token-props object, or forwarded React ref API; capture `event.api` through grid events when needed.

```ts
type DataGridProps<TData = unknown> = AgGridReactProps<TData> &
  Pick<ComponentPropsWithoutRef<'div'>, 'className'>
```

## Spreadsheet setup and control

### `useSpreadsheet`

Creates the stable hook-owned binding/controller and composes Community grid configuration. Requires stable data/binding ownership, client-side body rows, IDs, and a synchronous adapter. See [Spreadsheet mode](./spreadsheet-mode.md).

```ts
function useSpreadsheet<TData>(options: SpreadsheetOptions<TData>): SpreadsheetBinding<TData>
```

### `SpreadsheetOptions`

Required: `gridProps`, `data`, `bindings`. Pass the acknowledgment associated with each owned projection. `onResult` observes accepted/rejected operation results; `onError` observes clipboard/history errors. The hook enforces read-only edit requests; configure actual editability on columns.

```ts
interface SpreadsheetOptions<TData> {
  gridProps: AgGridReactProps<TData>
  data: SpreadsheetDataAdapter<TData>
  readonly bindings: readonly ColumnBinding<TData>[]
  onResult?: (result: OperationResult) => void
  acknowledgment?: DataAcknowledgment
  viewport?: SpreadsheetViewport
  formatCell?: (address: CellAddress, value: unknown) => string
  copySelectedRows?: boolean
  writeText?: (text: string) => Promise<void>
  onError?: (error: unknown) => void
  history?: {
    maxCommands?: number
    maxBytes?: number
  }
  maxCommands?: number
  maxBytes?: number
  maxHistoryCommands?: number
  maxHistoryBytes?: number
  handleMode?: SpreadsheetHandleMode
  handleLabels?: Partial<SpreadsheetHandleLabels>
  selectionSummary?: (snapshot: SelectionSnapshot) => string
}
```

| Option             | Default or precedence                                                                                                                                                             |
| ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `handleMode`       | `'fill'`                                                                                                                                                                          |
| `copySelectedRows` | `false` (ordinary range/focus copy). With `true`, Copy and Cut export whole covered rows; successful Cut clears accepted writable cells across all their displayed bound columns. |
| `formatCell`       | Default text serialization, with lossless locale-aware numbers for factory parsers.                                                                                               |
| `writeText`        | Browser clipboard write; failure goes to `onError`.                                                                                                                               |
| `handleLabels`     | Partial overrides of pt-BR handle labels.                                                                                                                                         |
| `selectionSummary` | pt-BR selected-cell count announcement.                                                                                                                                           |
| Command limit      | `history.maxCommands ?? maxHistoryCommands ?? maxCommands ?? 100`                                                                                                                 |
| Byte limit         | `history.maxBytes ?? maxHistoryBytes ?? maxBytes ?? 5_242_880`                                                                                                                    |

Prefer nested `history` options; the top-level limit names remain supported. Initial history limits belong to the mounted controller; changing options does not recreate history. Register normal AG Grid handlers in the input `gridProps` so the hook composes them.

### `SpreadsheetBinding`

Attach `hostRef`, render composed `gridProps`, and access imperative methods via `controller`. The selection store supports `useSyncExternalStore`. Cell and handle methods are primarily for custom renderer composition; registrations return cleanup functions. The host ref shape works with React 18 and 19.

```ts
interface SpreadsheetBinding<TData> {
  hostRef: {
    current: HTMLDivElement | null
  }
  gridProps: AgGridReactProps<TData>
  selection: SelectionStore
  handleLabels: SpreadsheetHandleLabels
  registerCell(element: HTMLElement, position: CellPosition): () => void
  getCellState(position: CellPosition): SpreadsheetCellState
  subscribeCell(position: CellPosition, listener: () => void): () => void
  handlePointerDown(
    position: CellPosition,
    mode: Exclude<SpreadsheetHandleMode, 'none'>,
    input: SpreadsheetHandlePointerInput,
  ): void
  handleKeyDown(
    position: CellPosition,
    mode: Exclude<SpreadsheetHandleMode, 'none'>,
    key: string,
    altKey?: boolean,
  ): boolean
  isHandleSessionActive(): boolean
  consumeHandleFocusRequest?(position: CellPosition): boolean
  controller: SpreadsheetController
  registerEditor: EditorRegistry['register']
}
```

### `SpreadsheetController`

`execute`, `paste`, `clear`, `bulkEdit`, and `fill` are synchronous operations; copy/cut are asynchronous clipboard writes. `cut` may return null if a pending write becomes stale; undo/redo return null when unavailable or invalidated. `registerShortcutCommand` aliases `registerCommand`; the returned function unregisters the handler. Handler types are `extend`, `clear`, `undo`, `redo`, and `bulk`. `synchronize` reconciles owned acknowledgments or external replacements.

```ts
interface SpreadsheetController {
  execute(input: OperationInput): OperationResult
  fill(
    targetRange: RangeShape,
    options: { readonly axis: 'row' | 'column'; readonly alt: boolean },
  ): OperationResult
  copy(): Promise<void>
  cut(): Promise<OperationResult | null>
  paste(text: string): OperationResult
  clear(): OperationResult
  bulkEdit(rawDraft: unknown): OperationResult
  undo(): OperationResult | null
  redo(): OperationResult | null
  getHistoryState(): { undoCount: number; redoCount: number; bytes: number }
  synchronize(acknowledgment?: DataAcknowledgment): void
  getSelection(): SelectionSnapshot
  subscribeSelection(listener: (snapshot: SelectionSnapshot) => void): () => void
  registerCommand(
    type: ShortcutAction['type'],
    handler: (shortcut: ShortcutAction, event: ShortcutEvent) => boolean | void,
  ): () => void
  registerShortcutCommand(
    type: ShortcutAction['type'],
    handler: (shortcut: ShortcutAction, event: ShortcutEvent) => boolean | void,
  ): () => void
}
```

For custom command event/handler types, use indexed access from `SpreadsheetController` instead of importing internal shortcut types. `fill` receives a target range plus `{ axis, alt }`; `alt` toggles alternate sequence/copy behavior. `getHistoryState().bytes` measures retained history snapshots, not total application memory.

### `SpreadsheetViewport`

Optional viewport bounds and scrolling overrides for drag autoscroll. Bounds are client-coordinate left/top/right/bottom values. `getBounds` takes precedence over `bounds`; `scroll(dx, dy)` receives pixel deltas. Default maximum speed is 600 pixels per second.

```ts
interface SpreadsheetViewport {
  bounds?: ViewportRect | (() => ViewportRect)
  getBounds?: () => ViewportRect
  scroll?: (dx: number, dy: number) => void
  maxSpeedPxPerSecond?: number
}
```

### `SpreadsheetHandleMode`

Default: `fill`. `range` resizes selection without writes; `none` hides handles. See [selection and handles](./spreadsheet-mode.md#selection-and-handles).

```ts
type SpreadsheetHandleMode = 'range' | 'fill' | 'none'
```

### `SpreadsheetHandleLabels`

Strings for accessible range/fill handle labels. Defaults are Brazilian Portuguese; pass partial overrides through `handleLabels`.

```ts
interface SpreadsheetHandleLabels {
  range: string
  fill: string
}
```

### `SpreadsheetHandlePointerInput`

Pointer information passed by a custom handle to the binding. `altKey` selects the alternate fill behavior.

```ts
interface SpreadsheetHandlePointerInput {
  readonly pointerId: number
  readonly clientX: number
  readonly clientY: number
  readonly altKey: boolean
}
```

### `SpreadsheetCellState`

Per-cell handle visibility, active preview state, and accessible selection summary. Subscribe using the binding rather than reading a snapshot once when rendering reactive content.

```ts
interface SpreadsheetCellState {
  readonly handleMode: Exclude<SpreadsheetHandleMode, 'none'> | null
  readonly preview: boolean
  readonly selectionSummary: string
}
```

## Renderers and editors

### `SpreadsheetCellRenderer`

Default wrapper/content renderer for eligible bound body cells without an effective consumer renderer/selector. Uses `renderContent`, then `valueFormatted`, then plain text. See [renderer guide](./spreadsheet-cell-renderer.md).

```ts
function SpreadsheetCellRenderer<TData = unknown, TValue = unknown>(
  params: SpreadsheetCellRendererParams<TData, TValue>,
): ReactNode
```

### `SpreadsheetCellRendererParams`

Extends the peer `ICellRendererParams`. `getSpreadsheet` is hook-owned and can return null during initialization; consumers must not allocate or replace the connection. `renderContent` can intentionally return empty content.

```ts
interface SpreadsheetCellRendererParams<
  TData = unknown,
  TValue = unknown,
> extends ICellRendererParams<TData, TValue> {
  renderContent?(params: SpreadsheetCellRendererParams<TData, TValue>): ReactNode
  getSpreadsheet?(): SpreadsheetBinding<TData> | null
}
```

### `SpreadsheetCell`

Wraps custom body-cell content with selection/handle behavior. It does not instantiate an AG Grid renderer. See [Custom Renderer](./custom-renderer.md) for eligible-row guards and initialization fallback.

```ts
function SpreadsheetCell<TData>(props: SpreadsheetCellProps<TData>): ReactNode
```

### `SpreadsheetCellProps`

`position` uses the displayed body-row index and column ID. It is a view position, not an authoritative domain row address. Children are consumer-owned React content.

```ts
interface SpreadsheetCellProps<TData> {
  spreadsheet: SpreadsheetBinding<TData>
  position: CellPosition
  children: ReactNode
}
```

### `SpreadsheetTextEditor`

Optional reactive text editor with a raw-draft bridge for bulk operations. Select it in `cellEditor`; the hook composes registration automatically. Outside the hook, a consumer can supply an editor registry explicitly.

```ts
function SpreadsheetTextEditor<TData = unknown>(
  props: SpreadsheetTextEditorProps<TData>,
): ReactElement
```

### `SpreadsheetTextEditorParams`

`inputAriaLabel` defaults to the column ID. `registerEditor` connects the stable row/column address and draft; normally supplied by `useSpreadsheet`.

```ts
interface SpreadsheetTextEditorParams {
  registerEditor?: EditorRegistry['register']
  inputAriaLabel?: string
}
```

### `SpreadsheetTextEditorProps`

Extends peer reactive editor props for string values. Rendering/editing integration uses AG Grid React public editor APIs.

```ts
type SpreadsheetTextEditorProps<TData = unknown> = CustomCellEditorProps<TData, string> &
  SpreadsheetTextEditorParams
```

### `SpreadsheetNumberEditor`

Optional numeric editor using the current binding parser, preserving raw drafts, nulls, and stored precision. Invalid final edits cancel. See [numeric editor](./spreadsheet-number-editor.md).

```ts
function SpreadsheetNumberEditor<TData = unknown>(
  props: SpreadsheetNumberEditorProps<TData>,
): ReactElement
```

### `SpreadsheetNumberEditorParams`

Factory parser locale is authoritative; an explicit conflicting editor locale throws. Without a parser-provided locale the default is pt-BR. The hook supplies registration and parser integration; private bridge fields are not consumer configuration.

```ts
interface SpreadsheetNumberEditorParams {
  locale?: SpreadsheetNumberLocale
  inputAriaLabel?: string
  registerEditor?: EditorRegistry['register']
}
```

### `SpreadsheetNumberEditorProps`

Extends peer reactive editor props for `number | null`; display precision does not restrict the underlying stored number.

```ts
type SpreadsheetNumberEditorProps<TData = unknown> = CustomCellEditorProps<TData, number | null> &
  SpreadsheetNumberEditorParams
```

### `createSpreadsheetNumberParser`

Creates a stable localized binding parser. Preserves finite numbers/null, parses localized strings, maps empty input to null, and rejects malformed values. Default locale: pt-BR. Custom parsing still must produce finite numbers or null; exceptions become localized rejections.

```ts
function createSpreadsheetNumberParser<TData = unknown>(
  options?: SpreadsheetNumberParserOptions<TData>,
): SpreadsheetNumberParser<TData>
```

### `SpreadsheetNumberLocale`

Supported numeric input locales only. This is independent of grid `localeText` and display formatters.

```ts
type SpreadsheetNumberLocale = 'pt-BR' | 'en-US'
```

### `SpreadsheetNumberParser`

A binding parser carrying immutable factory locale metadata. The hook uses factory metadata for consistent editor and lossless clipboard behavior; assigning a locale property to an arbitrary function is not equivalent.

```ts
type SpreadsheetNumberParser<TData = unknown> = NonNullable<ColumnBinding<TData>['parse']> & {
  readonly locale: SpreadsheetNumberLocale
}
```

### `SpreadsheetNumberParserOptions`

`locale` defaults to pt-BR. `parse` receives the full input context; `invalidMessage` customizes fallback rejection text. Business validation belongs to the application.

```ts
type SpreadsheetNumberParserOptions<TData = unknown> = {
  locale?: SpreadsheetNumberLocale
  parse?: NonNullable<ColumnBinding<TData>['parse']>
  invalidMessage?: string
}
```

## Data ownership and bindings

### `createImmutableDataAdapter`

Creates a synchronous adapter with row-ID lookup, immutable batch writes, conflict detection, and acknowledgment publication. `publish` must make the authoritative snapshot visible before returning. See [bindings](./column-bindings.md).

```ts
function createImmutableDataAdapter<TData>(
  options: ImmutableDataAdapterOptions<TData>,
): SpreadsheetDataAdapter<TData>
```

### `ImmutableDataAdapterOptions`

Use the same stable bindings as the hook. `getRowId(row)` returns the same domain ID that the grid uses. `publish` receives one next snapshot and its acknowledgment when actual accepted changes exist.

```ts
interface ImmutableDataAdapterOptions<TData> {
  getSnapshot(): DataSnapshot<TData>
  publish(nextSnapshot: DataSnapshot<TData>, acknowledgment: DataAcknowledgment): void
  getRowId(row: TData): string
  readonly bindings: readonly ColumnBinding<TData>[]
}
```

### `SpreadsheetDataAdapter`

Consumer-implemented port. Versions must reflect authoritative data changes; `commitChanges` returns actual accepted deltas/rejections synchronously. A custom adapter can implement writes independently of binding writers with `writable: true`.

```ts
interface SpreadsheetDataAdapter<TData> {
  getVersion(): number
  getRow(rowId: string): TData | undefined
  commitChanges(batch: ChangeBatch): CommitResult
}
```

### `DataSnapshot`

Versioned authoritative rows. Keep snapshot rows immutable and React projection data separate where necessary. Version advances must be observable synchronously through the adapter.

```ts
interface DataSnapshot<TData> {
  version: number
  readonly rows: readonly TData[]
}
```

### `DataAcknowledgment`

Links an owned operation to its published data version so projection reconciliation can preserve history. Do not reuse it to classify an unrelated external reset as an owned update.

```ts
interface DataAcknowledgment {
  operationId: string
  dataVersion: number
}
```

### `ColumnBinding`

Maps a column ID to authoritative row reads/writes, optional parsing, and value snapshots. A writer makes it writable; `writable: true` can admit a custom-adapter write without one. `writable: false` does not disable an existing writer. Use effective grid `editable: false` or omit the writer for read-only cells. See [column bindings](./column-bindings.md).

```ts
interface ColumnBinding<TData> {
  columnId: string
  read(row: TData): unknown
  write?(row: TData, value: unknown): TData
  writable?: boolean
  parse?(input: ParseInput<TData>): ParseResult
  codec?: ValueCodec
}
```

### `ValueCodec`

Clone values without shared mutable history state, compare semantic equality, and return a finite non-negative byte estimate. The default supports primitives, nullish values, and Date; other objects need a consumer codec.

```ts
interface ValueCodec {
  clone(value: unknown): unknown
  equals(a: unknown, b: unknown): boolean
  measure(value: unknown): number
}
```

### `ParseInput`

The raw operation input plus authoritative row, stable address, and operation source. A clear candidate passes an empty string when a parser exists. Ordinary inline edit requests are already parsed and bypass this runner callback; the supplied number editor invokes its binding parser before emitting its value.

```ts
interface ParseInput<TData> {
  input: unknown
  row: TData
  address: CellAddress
  source: ChangeSource
}
```

### `ParseResult`

Discriminated parser outcome. Rejecting one normal-operation destination leaves that cell unchanged; other accepted destinations may still commit.

```ts
type ParseResult =
  | {
      ok: true
      value: unknown
    }
  | {
      ok: false
      message?: string
    }
```

## Operations and results

### `CellAddress`

Stable domain row ID plus bound column ID. Use for data operations and rejection reporting.

```ts
type CellAddress = {
  rowId: string
  columnId: string
}
```

### `CellPosition`

Displayed body-row index plus column ID. Use for selection and renderer geometry, not form array indexing.

```ts
type CellPosition = {
  rowIndex: number
  columnId: string
}
```

### `CellChange`

Actual before/after values at a stable address. Codecs protect snapshots used by history.

```ts
interface CellChange extends CellAddress {
  oldValue: unknown
  newValue: unknown
}
```

### `ChangeSource`

Origin of a mutation; no separate source string is introduced for undo/redo. Replay retains its source and changes `mode`.

```ts
type ChangeSource = 'edit' | 'paste' | 'cut' | 'delete' | 'fill' | 'bulk'
```

### `ChangeBatch`

Versioned batch delivered to the adapter. `operationId` identifies the operation; optional `commandId` relates history replay. Changes carry expected old values for conflict detection.

```ts
interface ChangeBatch {
  operationId: string
  source: ChangeSource
  baseDataVersion: number
  readonly changes: readonly CellChange[]
  mode: OperationMode
  commandId?: string
}
```

### `CommitResult`

Adapter outcome containing actual accepted changes, rejected cells, and resulting version. Normal batches may partially succeed; replay must not accept a partial command.

```ts
interface CommitResult {
  operationId: string
  dataVersion: number
  readonly changes: readonly CellChange[]
  readonly rejected: readonly RejectedCell[]
}
```

### `OperationResult`

Commit result plus source/mode metadata, supplied to observers and returned by controller mutation methods.

```ts
interface OperationResult extends CommitResult {
  source: ChangeSource
  mode: OperationMode
  commandId?: string
}
```

### `RejectedCell`

Stable address and rejection reason with an optional human-readable message.

```ts
interface RejectedCell extends CellAddress {
  reason: RejectionReason
  message?: string
}
```

### `RejectionReason`

`readonly`: editing denied; `parse`: input rejected; `missing`: row/binding absent; `conflict`: old value mismatch; `consumer`: unsupported value/codec/writer or custom adapter rejection.

```ts
type RejectionReason = 'readonly' | 'parse' | 'missing' | 'conflict' | 'consumer'
```

### `CandidateCell`

A proposed cell input. `raw` uses binding parsing; `parsed` bypasses it; `clear` parses an empty string or becomes null without a parser.

```ts
interface CandidateCell extends CellAddress {
  input: unknown
  inputKind: 'raw' | 'parsed' | 'clear'
}
```

### `OperationInput`

Controller execution input. Duplicate candidates for the same address are deduplicated. Omitted `mode` means normal. Keep replay metadata for deliberate custom integrations.

```ts
interface OperationInput {
  source: ChangeSource
  readonly candidates: readonly CandidateCell[]
  mode?: OperationMode
  commandId?: string
}
```

### `OperationMode`

Normal mutation or history replay direction. The source remains the original operation source.

```ts
type OperationMode = 'normal' | 'undo' | 'redo'
```

### `OperationRunner`

Public port shape for operation execution and subscriptions. No operation-runner factory is exported; consumers normally use `spreadsheet.controller`. Optional failure subscriptions report execution failure.

```ts
interface OperationRunner {
  run(input: OperationInput): OperationResult
  subscribe(listener: (result: OperationResult) => void): () => void
  subscribeFailure?(listener: (error: unknown) => void): () => void
}
```

## Selection and editor contracts

### `SelectionSnapshot`

Snapshot of view selection with topology revision, anchor/focus, active range, and inclusive row-bound ranges. Range column IDs are explicit; this nested range shape is not a separately exported root type.

```ts
interface SelectionSnapshot {
  revision: number
  topologyVersion: number
  anchor: CellPosition | null
  focus: CellPosition | null
  activeRangeId: string | null
  readonly ranges: readonly RangeShape[]
}
```

### `SelectionAction`

Actions understood by the exposed selection store. View positions/ranges must match the current topology; prefer normal grid interactions unless deliberately managing selection.

```ts
type SelectionAction =
  | {
      type: 'replace'
      position: CellPosition
      range: RangeShape
    }
  | {
      type: 'add'
      position: CellPosition
      range: RangeShape
    }
  | {
      type: 'subtract'
      position: CellPosition
      range: RangeShape
    }
  | {
      type: 'extend'
      position: CellPosition
      range: RangeShape
    }
  | {
      type: 'focus'
      position: CellPosition
    }
  | {
      type: 'clear'
    }
```

### `SelectionStore`

Stable external store for subscriptions and selection actions. `reset` associates an empty selection with a topology version; `setTopology` and `restore` support coordinated custom integrations. No selection-store factory is exported.

```ts
interface SelectionStore {
  getSnapshot(): SelectionSnapshot
  subscribe(listener: (snapshot: SelectionSnapshot) => void): () => void
  dispatch(action: SelectionAction): void
  contains(position: CellPosition): boolean
  reset(topologyVersion: number): void
  setTopology(topology: SpreadsheetTopology): void
  restore(snapshot: SelectionSnapshot): void
}
```

### `SpreadsheetTopology`

Versioned, ordered body row IDs and bound displayed column IDs used for selection/operation resolution.

```ts
interface SpreadsheetTopology {
  version: number
  readonly rowIds: readonly string[]
  readonly columnIds: readonly string[]
}
```

### `TopologyChange`

Topology notification shape; exported as a contract, not an extra hook option or callback prop.

```ts
interface TopologyChange {
  reason: string
  topology: SpreadsheetTopology
}
```

### `EditorDraftBridge`

Custom editor raw-draft port. `cancel` must discard the active edit; optional `ownsTarget` identifies input ownership so bulk shortcuts do not steal input from unrelated controls.

```ts
interface EditorDraftBridge {
  getDraft(): unknown
  cancel(): void
  ownsTarget?(target: EventTarget | null): boolean
}
```

### `ActiveEditor`

Currently registered stable cell address and draft bridge.

```ts
interface ActiveEditor {
  address: CellAddress
  bridge: EditorDraftBridge
}
```

### `EditorRegistry`

Registers one editor bridge and returns cleanup. The hook exposes registration through its binding; no editor-registry factory is exported.

```ts
interface EditorRegistry {
  register(address: CellAddress, bridge: EditorDraftBridge): () => void
  getActive(): ActiveEditor | null
}
```

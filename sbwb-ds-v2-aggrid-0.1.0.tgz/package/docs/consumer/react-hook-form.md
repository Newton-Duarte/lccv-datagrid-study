# React Hook Form integration

Keep the form as the single data owner while editing its rows through Spreadsheet operations. Prerequisites: [standard installation](./standard-grid.md#install), the [Spreadsheet ownership rules](./spreadsheet-mode.md#ownership-rules), and [column bindings](./column-bindings.md).

This is application code using the public grid adapter, not a built-in RHF export. `react-hook-form`, Zod, and the resolver are optional dependencies of your application. The complete example uses the APIs in these versions:

```sh
npm install react-hook-form@^7.92.0 @hookform/resolvers@7.0.9 zod@^4.6.7
```

## Data and validation flow

1. The parent creates `useForm` with a Project array and schema resolver. The grid receives that form; it does not create another form.
2. `useWatch` supplies the grid's row projection. The stable adapter reads current rows synchronously through `form.getValues`.
3. `applyProjectChangesToForm` publishes accepted batches using synchronous `setValue` calls to leaf fields, matching domain IDs to current form indexes. It advances the data version and publishes the acknowledgment before returning.
4. Validation is scheduled outside the synchronous commit. Draft budgets may be `null`; the schema can still require a non-negative budget for submission. Parsing failures reject the grid operation; domain validation displays form errors.
5. Cell errors map row IDs back to current form indexes. Grid sort/filter indexes must never be used as form field indexes.
6. Save finishes the active editor before cloning and validating values. It persists the captured snapshot and updates the saved baseline. Cancel stops the editor without committing, resets form values, advances the adapter version, and synchronizes external data to clear stale history.

`useFieldArray` is unnecessary for this fixed-row example. If your application adds/removes rows, own those structural operations in the form, keep domain IDs separate from RHF field keys, and synchronize the Spreadsheet topology/history after changes. Keep the form instance and bindings stable for the mounted integration.

## Complete example

Copy all six files into one directory and render `ProjectForm`. Edit unlocks the grid; Save validates and persists; Cancel restores the baseline; Retry keeps failed saves recoverable. `saveProjects` is an explicit demonstration stub; replace its captured-snapshot request with your application's persistence or pass a `save` function to `ProjectForm`.

### `project-data.ts`

Defines stable domain IDs, nullable drafts, initial values, cloning, and immutable bindings.

<!-- consumer-example: project-form/project-data.ts -->

```ts
import { createSpreadsheetNumberParser } from 'sbwb-ds-v2-aggrid'
import type { ColumnBinding } from 'sbwb-ds-v2-aggrid'
export type Project = {
  id: string
  name: string
  budget: number | null
}
export type ProjectsFormValues = { projects: Project[] }
export function createProjectsFormValues(): ProjectsFormValues {
  return {
    projects: [
      { id: 'project-1', name: 'Website refresh', budget: 10000 },
      { id: 'project-2', name: 'Internal portal', budget: 20000 },
      { id: 'project-3', name: 'Reporting service', budget: 5000 },
    ],
  }
}

export function cloneProjects(values: ProjectsFormValues): ProjectsFormValues {
  return { projects: values.projects.map((project) => ({ ...project })) }
}
export const PROJECT_BINDINGS: readonly ColumnBinding<Project>[] = [
  {
    columnId: 'name',
    read: (row) => row.name,
    parse: ({ input }) => ({ ok: true, value: input == null ? '' : String(input) }),
    write: (row, value) => (typeof value === 'string' ? { ...row, name: value } : row),
  },
  {
    columnId: 'budget',
    read: (row) => row.budget,
    parse: createSpreadsheetNumberParser<Project>(),
    write: (row, value) =>
      value === null || (typeof value === 'number' && Number.isFinite(value))
        ? { ...row, budget: value }
        : row,
  },
]
```

### `project-schema.ts`

Defines domain validation separately from numeric input conversion.

<!-- consumer-example: project-form/project-schema.ts -->

```ts
import { z } from 'zod'
import type { Project, ProjectsFormValues } from './project-data.ts'
export const projectSchema: z.ZodType<Project, Project> = z.object({
  id: z.string(),
  name: z.string().refine((name) => name.trim().length > 0, 'Project name is required.'),
  budget: z
    .number({ error: 'Budget must be a finite number of zero or more.' })
    .nullable()
    .refine((budget) => budget !== null && budget >= 0, {
      message: 'Budget must be a finite number of zero or more.',
    }),
})

export const projectsFormSchema: z.ZodType<ProjectsFormValues, ProjectsFormValues> = z.object({
  projects: z.array(projectSchema),
})
```

### `project-grid.tsx`

Publishes to the form synchronously, maps validation by ID, and exposes edit/reset controls to the parent.

<!-- consumer-example: project-form/project-grid.tsx -->

```tsx
import { useEffect, useMemo, useRef, useState } from 'react'
import type { ReactElement } from 'react'
import { useWatch } from 'react-hook-form'
import type { UseFormReturn } from 'react-hook-form'
import type { ColDef, GridApi } from 'ag-grid-community'
import {
  DataGrid,
  SpreadsheetTextEditor,
  SpreadsheetNumberEditor,
  createImmutableDataAdapter,
  useSpreadsheet,
} from 'sbwb-ds-v2-aggrid'
import type { DataAcknowledgment, DataSnapshot, OperationResult } from 'sbwb-ds-v2-aggrid'
import { PROJECT_BINDINGS } from './project-data.ts'
import type { Project, ProjectsFormValues } from './project-data.ts'
const budgetFormat = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
export type ProjectGridControls = {
  finishEditing(): Promise<void>
  cancelEditing(): void
  synchronizeExternalData(): void
}

export type ProjectGridProps = {
  form: UseFormReturn<ProjectsFormValues>
  editable: boolean
  onReady(controls: ProjectGridControls): void
  onCommit?(result: OperationResult): void
}
export function ProjectGrid({ form, editable, onReady, onCommit }: ProjectGridProps): ReactElement {
  const projects = useWatch({ control: form.control, name: 'projects' })
  const errors = form.formState.errors
  const canEdit = useRef(editable)
  canEdit.current = editable
  const api = useRef<GridApi<Project> | null>(null)
  const version = useRef(0)
  const [acknowledgment, setAcknowledgment] = useState<DataAcknowledgment>()
  // This is the one place accepted grid operations write into React Hook Form.
  function applyProjectChangesToForm(next: DataSnapshot<Project>, ack: DataAcknowledgment): void {
    const current = form.getValues('projects')
    for (const project of next.rows) {
      const index = current.findIndex(({ id }) => id === project.id)
      if (index < 0) continue
      const options = { shouldDirty: true, shouldTouch: true, shouldValidate: false }
      if (current[index]!.name !== project.name)
        form.setValue(`projects.${index}.name`, project.name, options)
      if (!Object.is(current[index]!.budget, project.budget))
        form.setValue(`projects.${index}.budget`, project.budget, options)
    }
    version.current = next.version
    setAcknowledgment(ack)
    // Validation is deliberately outside the synchronous spreadsheet commit.
    queueMicrotask(() => {
      void form.trigger()
    })
  }
  const [data] = useState(() =>
    createImmutableDataAdapter<Project>({
      getSnapshot: () => ({
        version: version.current,
        rows: form.getValues('projects').map((row) => ({ ...row })),
      }),
      getRowId: (row) => row.id,
      bindings: PROJECT_BINDINGS,
      publish: applyProjectChangesToForm,
    }),
  )
  const columns = useMemo<ColDef<Project>[]>(() => {
    const hasError = (id: string | undefined, field: 'name' | 'budget') => {
      const index = form.getValues('projects').findIndex((row) => row.id === id)
      return index >= 0 && form.getFieldState(`projects.${index}.${field}`).error ? true : false
    }
    return [
      {
        field: 'name',
        colId: 'name',
        headerName: 'Project name',
        editable: () => canEdit.current,
        cellEditor: SpreadsheetTextEditor<Project>,
        cellEditorParams: { inputAriaLabel: 'Project name editor' },
        cellClassRules: { 'project-form-cell--invalid': ({ data }) => hasError(data?.id, 'name') },
      },
      {
        field: 'budget',
        colId: 'budget',
        headerName: 'Budget',
        editable: () => canEdit.current,
        cellDataType: 'number',
        cellEditor: SpreadsheetNumberEditor<Project>,
        cellEditorParams: { inputAriaLabel: 'Budget editor' },
        valueFormatter: ({ value }) => (value == null ? '' : budgetFormat.format(value)),
        cellClassRules: {
          'project-form-cell--invalid': ({ data }) => hasError(data?.id, 'budget'),
        },
      },
    ]
  }, [form])
  // Keep schema objects stable: replacing them on a value edit invalidates spreadsheet history.
  const [gridDefaults] = useState(() => ({
    getRowId: ({ data }: { data: Project }) => data.id,
    defaultColDef: {
      flex: 1,
      minWidth: 140,
      sortable: true,
      resizable: true,
    },
    onGridReady: (event: { api: GridApi<Project> }) => {
      api.current = event.api
    },
  }))
  const gridProps = useMemo(
    () => ({ ...gridDefaults, rowData: projects.map((row) => ({ ...row })), columnDefs: columns }),
    [gridDefaults, projects, columns],
  )
  useEffect(() => {
    api.current?.refreshCells({ force: true })
  }, [errors, editable])
  const spreadsheet = useSpreadsheet({
    gridProps,
    data,
    bindings: PROJECT_BINDINGS,
    acknowledgment,
    onResult: (result) => {
      if (result.changes.length) onCommit?.(result)
    },
  })
  useEffect(() => {
    onReady({
      // AG Grid delivers edit requests asynchronously. Wait before locking or reading a save snapshot.
      finishEditing: () =>
        new Promise<void>((resolve) => {
          const grid = api.current
          if (!grid?.getEditingCells().length) {
            resolve()
            return
          }
          const stopped = () => {
            grid.removeEventListener('cellEditingStopped', stopped)
            resolve()
          }
          grid.addEventListener('cellEditingStopped', stopped)
          grid.stopEditing(false)
        }),
      cancelEditing: () => api.current?.stopEditing(true),
      synchronizeExternalData: () => {
        version.current += 1
        setAcknowledgment(undefined)
        spreadsheet.controller.synchronize()
      },
    })
  }, [onReady, spreadsheet.controller])
  return (
    <>
      <div ref={spreadsheet.hostRef} className="project-form-grid" aria-label="Projects grid">
        <DataGrid<Project> {...spreadsheet.gridProps} />
      </div>
      <ul className="project-form-errors" aria-label="Project validation errors">
        {projects.flatMap((row, index) =>
          (['name', 'budget'] as const).map((field) =>
            errors.projects?.[index]?.[field]?.message ? (
              <li key={`${row.id}-${field}`}>
                {row.name || 'Unnamed project'} · {field}:{' '}
                {String(errors.projects[index]![field]!.message)}
              </li>
            ) : null,
          ),
        )}
      </ul>
    </>
  )
}
```

### `project-form.tsx`

Owns the form, saved baseline, pending-save guard, and Save/Cancel actions.

<!-- consumer-example: project-form/project-form.tsx -->

```tsx
import { zodResolver } from '@hookform/resolvers/zod'
import { useCallback, useRef, useState } from 'react'
import { useForm } from 'react-hook-form'
import { projectsFormSchema } from './project-schema.ts'
import { cloneProjects, createProjectsFormValues } from './project-data.ts'
import type { ProjectsFormValues } from './project-data.ts'
import { ProjectGrid } from './project-grid.tsx'
import type { ProjectGridControls } from './project-grid.tsx'
import { saveProjects } from './save-projects.ts'
import type { SaveProjects } from './save-projects.ts'
import 'sbwb-ds-v2-aggrid/styles/theme.css'
import './project-form.css'
export type ProjectFormProps = { save?: SaveProjects }
export function ProjectForm({ save = saveProjects }: ProjectFormProps) {
  // The consumer creates the form. The grid receives it, rather than owning another form.
  const form = useForm<ProjectsFormValues>({
    defaultValues: createProjectsFormValues(),
    shouldUnregister: false,
    resolver: zodResolver(projectsFormSchema),
  })
  const { isDirty, errors } = form.formState
  const baseline = useRef(createProjectsFormValues())
  const controls = useRef<ProjectGridControls | null>(null)
  const pending = useRef(false)
  const [editing, setEditing] = useState(false)
  const [status, setStatus] = useState<'saved' | 'saving' | 'invalid' | 'error'>('saved')
  const [error, setError] = useState('')
  const onReady = useCallback((next: ProjectGridControls) => {
    controls.current = next
  }, [])
  async function handleSave() {
    if (pending.current) return
    pending.current = true
    try {
      await controls.current?.finishEditing()
      const snapshot = cloneProjects(form.getValues())
      setStatus('saving')
      if (!(await form.trigger()) || !projectsFormSchema.safeParse(snapshot).success) {
        setStatus('invalid')
        return
      }
      await save(snapshot)
      baseline.current = cloneProjects(snapshot)
      form.resetDefaultValues(snapshot, { keepIsValid: true })
      setStatus('saved')
      setEditing(false)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
      setStatus('error')
    } finally {
      pending.current = false
    }
  }
  function handleCancel() {
    if (pending.current) return
    controls.current?.cancelEditing()
    form.reset(cloneProjects(baseline.current))
    controls.current?.synchronizeExternalData()
    setStatus('saved')
    setEditing(false)
  }
  return (
    <div className="project-form">
      <div className="project-form-toolbar">
        {!editing ? (
          <button type="button" onClick={() => setEditing(true)}>
            Edit
          </button>
        ) : (
          <>
            <button type="button" disabled={status === 'saving'} onClick={() => void handleSave()}>
              Save
            </button>
            <button type="button" disabled={status === 'saving'} onClick={handleCancel}>
              Cancel
            </button>
            {status === 'error' && (
              <button type="button" onClick={() => void handleSave()}>
                Retry
              </button>
            )}
          </>
        )}
        <span role="status" aria-label="Project save status" aria-live="polite">
          {status === 'saving'
            ? 'Saving…'
            : status === 'error'
              ? `Save failed: ${error}`
              : status === 'invalid' && Object.keys(errors).length > 0
                ? 'Fix the highlighted fields before saving.'
                : isDirty
                  ? 'Unsaved changes'
                  : editing
                    ? 'No unsaved changes'
                    : 'View mode'}
        </span>
      </div>
      <ProjectGrid form={form} editable={editing && status !== 'saving'} onReady={onReady} />
    </div>
  )
}
```

### `save-projects.ts`

Captures the submitted snapshot before the asynchronous demonstration request.

<!-- consumer-example: project-form/save-projects.ts -->

```ts
import { cloneProjects } from './project-data.ts'
import type { ProjectsFormValues } from './project-data.ts'
export type SaveProjects = (values: ProjectsFormValues) => Promise<void>

export async function saveProjects(values: ProjectsFormValues): Promise<void> {
  const snapshot = cloneProjects(values)
  // Replace the delay with your application's request using this captured snapshot.
  await new Promise<void>((resolve) => window.setTimeout(resolve, 600))
  void snapshot
}
```

### `project-form.css`

Supplies the required grid height, form layout, and error styling.

<!-- consumer-example: project-form/project-form.css -->

```css
.project-form {
  display: grid;
  gap: 12px;
  padding: 16px;
  min-width: 0;
}

.project-form-grid {
  height: 240px;
  min-width: 0;
  color: #202020;
}

.project-form-toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
}
.project-form button {
  border: 1px solid #374151;
  background: #1f2937;
  color: #f3f4f6;
  font: inherit;
  font-size: 13px;
  padding: 7px 12px;
  cursor: pointer;
  border-radius: 5px;
}

.project-form button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

.project-form-grid button {
  height: 28px;
  line-height: 20px;
  padding: 2px 10px;
  border-color: #d1d5db;
  background: #f9fafb;
  color: #202020;
  vertical-align: middle;
}
.project-form :is(button, input, select):focus-visible {
  outline: 2px solid var(--color-sky-500, #0ea5e9);
  outline-offset: 2px;
}

.project-form-errors {
  margin: 0;
  padding-left: 20px;
  font-size: 13px;
}

.project-form-errors:empty {
  display: none;
}

.project-form-cell--invalid {
  box-shadow: inset 0 -2px #b91c1c;
}
```

## Save, Cancel, and external changes

`finishEditing` waits for AG Grid's public `cellEditingStopped` event. Calling `stopEditing(false)` and immediately reading the form can save the previous value. Preserve the wait before validation or locking editing. Invalid numeric drafts are canceled by the number editor; schema-invalid accepted values remain visible for correction.

`resetDefaultValues(snapshot, { keepIsValid: true })` updates the saved dirty baseline using the example's RHF version; it preserves current values. Cancel uses `reset` because it intentionally replaces values. Keep those two operations distinct.

## Autosave considerations

Autosave additionally needs serialized requests, captured snapshots, handling of edits made during an in-flight save, stale-response protection, retry, and unmount/data-owner lifecycle handling. Successful responses must update the saved baseline without replacing newer form values. The Save/Cancel example does not provide those coordination guarantees; implement them explicitly when adding autosave.

For API details, see the official [setValue](https://react-hook-form.com/docs/useform/setvalue), [getValues](https://react-hook-form.com/docs/useform/getvalues), [useWatch](https://react-hook-form.com/docs/usewatch), and [trigger](https://react-hook-form.com/docs/useform/trigger) documentation. Grid contracts remain in the [API reference](./api-reference.md).

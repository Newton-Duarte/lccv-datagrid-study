# Consumer AI rules for sbwb-ds-v2-aggrid

These rules apply when generating application code using this package. Read the relevant guide before writing code.

## Required rules

1. Import this library's runtime exports and types from `sbwb-ds-v2-aggrid`. Import CSS from its documented style subpaths. Never import this package's private source or distribution paths.
2. Render `DataGrid`. Peer imports such as `ColDef`, `GridApi`, `AgGridReactProps`, `themeQuartz`, React hooks, and locale maps are allowed from their owning packages. Do not replace the wrapper with `AgGridReact`.
3. Explicitly import `sbwb-ds-v2-aggrid/styles/theme.css` and give the grid's parent a non-zero height. The theme stylesheet includes design tokens.
4. Use Community configuration. Do not introduce AG Grid Enterprise modules or features such as row grouping/pivoting, Master/Detail, Server-Side Row Model, or Excel export. Custom Spreadsheet selection/clipboard/fill/history use `useSpreadsheet`, not Enterprise settings.
5. Pass ordinary Community props and callbacks through `DataGrid`. Consumers own rows, columns, events, persistence, and application/form state. There are no predefined package column types or data-fetching APIs.
6. Use the modern Theming API. Overrides through inherited design tokens, scoped `--ag-*`, `className`, and the `theme` prop are supported. Do not add legacy grid/theme CSS, `theme="legacy"`, or a required `ag-theme-quartz` class.
7. Default labels are pt-BR. Use `localeText` to override them and recreate the grid to switch languages. Numeric parsing locale, display formatting, and browser-native control locale are independent.
8. For Spreadsheet mode, keep adapter/binding ownership stable and immutable; use stable domain row IDs and matching bound column IDs. Publish authoritative data synchronously, project it into React, and return owned acknowledgments to the hook. Remount for a new data owner or binding mapping.
9. Attach the hook's `hostRef` and pass its composed `gridProps` to `DataGrid`; preserve composed handlers and renderer/editor connections. Do not disable `readOnlyEdit` in Spreadsheet mode.
10. Write through bindings/adapters. AG Grid `valueParser`/`valueSetter` do not replace replayable binding parsing/writing. `writable: false` does not disable a present writer; use grid editability or omit the writer for read-only cells.
11. Prefer `renderContent` for content customization. Full custom renderers need valid body-cell position checks, the hook-owned accessor, and initialization fallback. Never invent or populate private bridge fields.
12. RHF integration is optional application code. Keep one form owner, publish accepted changes synchronously by row ID, validate outside commit, finish active editing before Save, and synchronize after Cancel/reset. `useFieldArray` is not required for fixed rows.
13. Verify names against the API reference. A type nested in an exported interface may not itself be a root export; use indexed access instead of inventing imports.

## Choose a guide

| Task                                                                                                     | Guide                                                     |
| -------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| Install compatible peers, import styles, size the host, and render a complete typed Community grid.      | [Standard grid](./standard-grid.md)                       |
| Configure fields, IDs, defaults, sorting/filtering, display formatting, renderers, and editors.          | [Column definitions](./column-definitions.md)             |
| Connect the synchronous adapter and hook; use selection, clipboard, editing, fill, and history.          | [Spreadsheet mode](./spreadsheet-mode.md)                 |
| Map column IDs to authoritative reads, immutable writes, parsing, codecs, and stable ownership.          | [Column bindings](./column-bindings.md)                   |
| Keep form-owned rows with synchronous writes, ID-mapped validation, and complete Save/Cancel code.       | [React Hook Form](./react-hook-form.md)                   |
| Apply required CSS, inherited design tokens, scoped AG Grid variables, and modern theme overrides.       | [Theme](./theme.md)                                       |
| Override pt-BR grid labels, recreate on language changes, and distinguish input/display locales.         | [Locale](./locale.md)                                     |
| Customize default cell content with renderContent while retaining selection and handles.                 | [SpreadsheetCellRenderer](./spreadsheet-cell-renderer.md) |
| Connect localized numeric parsing/editing with nullable storage, precision, and lossless clipboard text. | [SpreadsheetNumberEditor](./spreadsheet-number-editor.md) |
| Own a renderer with SpreadsheetCell, safe initialization, position guards, and input ownership.          | [Custom Renderer](./custom-renderer.md)                   |
| Look up every public component, hook, helper, interface, type, controller method, and default.           | [API reference](./api-reference.md)                       |

The package documentation entry is [llms.txt](../llms.txt).

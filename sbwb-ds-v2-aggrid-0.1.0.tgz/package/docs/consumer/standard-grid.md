# Standard DataGrid

Install and render a typed Community grid. For editing with range selection, clipboard operations, and history, read [Spreadsheet mode](./spreadsheet-mode.md).

## Install

In an existing React 18 or 19 app:

```sh
npm install sbwb-ds-v2-aggrid @ag-grid-community/locale ag-grid-community ag-grid-react
```

Use matching React and React DOM major versions and matching AG Grid Community/React versions. TypeScript apps should use matching React type majors.

| Peer                                 | Supported range        |
| ------------------------------------ | ---------------------- |
| `react`, `react-dom`                 | `^18.0.0 \|\| ^19.0.0` |
| `ag-grid-community`, `ag-grid-react` | `>=34.0.0`             |
| `@ag-grid-community/locale`          | `^36.2.0`              |

Examples use the installed AG Grid 36.2 API. When installing another supported AG Grid release, check that release's options and keep the two AG Grid packages aligned.

## Required setup

- Import components from `sbwb-ds-v2-aggrid` and explicitly import `sbwb-ds-v2-aggrid/styles/theme.css` once in your application. It includes the design tokens.
- Give the parent a non-zero height. `DataGrid` fills its parent.
- Supply your own rows and column definitions. `ColDef` and other AG Grid types come from the peer packages.
- Community modules, the default token-backed Quartz theme, and Brazilian Portuguese grid labels are supplied automatically.
- Community props and event handlers pass through to AG Grid. The wrapper adds an optional `className`; it does not add data fetching or form state.
- Use the modern Theming API. Do not import legacy `ag-grid.css`/`ag-theme-quartz.css`, set `theme="legacy"`, or require `ag-theme-quartz`.
- Keep features within AG Grid Community. Enterprise row grouping, pivoting, Master/Detail, Server-Side Row Model, and Excel export are outside this package.

## Complete example

Adapted from the working Quick Start. Columns and defaults are stable module-level objects. Sorting, filtering, and resizing are enabled through ordinary column defaults.

### `users-grid.tsx`

<!-- consumer-example: standard-grid/users-grid.tsx -->

```tsx
import type { ColDef } from 'ag-grid-community'
import { DataGrid } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'

type Row = { name: string; team: string; active: boolean }

const rows: Row[] = [
  { name: 'Ada', team: 'Platform', active: true },
  { name: 'Grace', team: 'Infrastructure', active: true },
  { name: 'Katherine', team: 'Analytics', active: false },
]

const columns: ColDef<Row>[] = [{ field: 'name' }, { field: 'team' }, { field: 'active' }]
const defaults: ColDef<Row> = {
  flex: 1,
  minWidth: 110,
  sortable: true,
  filter: true,
  resizable: true,
}

export function UsersGrid() {
  return (
    <div style={{ height: 360, width: '100%' }}>
      <DataGrid<Row> rowData={rows} columnDefs={columns} defaultColDef={defaults} />
    </div>
  )
}
```

## Next steps

Read [column definitions](./column-definitions.md) for fields, IDs, callbacks, formatting, and editors; [Theme](./theme.md) for overrides; [Locale](./locale.md) for translations; and [API reference](./api-reference.md#datagridprops) for the wrapper contract.

For inherited configuration, consult the official [AG Grid column definitions](https://www.ag-grid.com/react-data-grid/column-definitions/) documentation.

# Column definitions

Use `ColDef<TData>` from `ag-grid-community` to configure what the grid displays and how a column behaves. Start with the [standard grid](./standard-grid.md); use [column bindings](./column-bindings.md) when operations go through `useSpreadsheet`.

## Rules

- `field` reads a property from a row. `colId` identifies a column independently of its header; give Spreadsheet columns explicit IDs matching their bindings.
- `defaultColDef` applies shared options; individual columns override them.
- `editable` can be a boolean or a callback. Ordinary `DataGrid` editing uses AG Grid's normal data-editing behavior; consumers choose how to manage their application data.
- `valueFormatter` changes displayed text. It does not change the stored value or establish the Spreadsheet clipboard serialization policy.
- `cellRenderer` controls rendered content; `cellRendererParams` supplies its parameters. `cellEditor` and `cellEditorParams` configure editing.
- Built-in sorting/filtering and `sortable`, `filter`, `resizable`, `flex`, and `minWidth` are Community configuration. This package does not supply predefined column types.
- AG Grid `valueParser`/`valueSetter` callbacks do not replace Spreadsheet `ColumnBinding.parse`/`write`. Clipboard, fill, bulk operations, and replay use the binding contract.

## Typed configuration

Copy both files below and render `ProjectGrid`. Its Project rows match the exported columns and `DataGrid<Project>` generic. The model is local application code; keep row data, columns, and the grid generic aligned when adapting any setup. The budget formatter preserves the stored number's precision.

### `project-columns.ts`

<!-- consumer-example: column-definitions/project-columns.ts -->

```ts
import type { ColDef } from 'ag-grid-community'

export type Project = { id: string; name: string; budget: number | null }
const budgetFormat = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
export const columns: ColDef<Project>[] = [
  { field: 'id', colId: 'id', editable: false },
  { field: 'name', colId: 'name', editable: true },
  {
    field: 'budget',
    colId: 'budget',
    cellDataType: 'number',
    editable: ({ data }) => data !== undefined,
    valueFormatter: ({ value }) => (value == null ? '' : budgetFormat.format(value)),
  },
]
export const defaults: ColDef<Project> = {
  flex: 1,
  minWidth: 140,
  sortable: true,
  filter: true,
  resizable: true,
}
```

### `project-grid.tsx`

<!-- consumer-example: column-definitions/project-grid.tsx -->

```tsx
import { DataGrid } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'
import { columns, defaults } from './project-columns.ts'
import type { Project } from './project-columns.ts'

const rows: Project[] = [
  { id: 'project-1', name: 'Website', budget: 10000 },
  { id: 'project-2', name: 'Portal', budget: null },
]
export function ProjectGrid() {
  return (
    <div style={{ height: 360, width: '100%' }}>
      <DataGrid<Project> rowData={rows} columnDefs={columns} defaultColDef={defaults} />
    </div>
  )
}
```

## Spreadsheet columns

The [Spreadsheet setup](./spreadsheet-mode.md#complete-example) supplies the synchronous adapter and composed grid props. Choose [SpreadsheetNumberEditor](./spreadsheet-number-editor.md) for its numeric column. Configure [renderContent](./spreadsheet-cell-renderer.md) for content customization, or read [Custom Renderer](./custom-renderer.md) when owning the renderer. Keep schema objects stable during row edits to avoid invalidating Spreadsheet history.

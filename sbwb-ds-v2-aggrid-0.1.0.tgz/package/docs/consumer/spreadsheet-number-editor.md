# SpreadsheetNumberEditor

Use the localized numeric editor with a numeric binding parser. Prerequisite: the [complete Spreadsheet setup](./spreadsheet-mode.md#complete-example). The example below replaces its budget binding and column; retain the name binding/column and existing adapter/hook/host setup.

## Rules

- Choose `SpreadsheetNumberEditor<Project>` in the column definition. Create `createSpreadsheetNumberParser<Project>()` once in the matching binding.
- The parser factory defaults to `pt-BR`; `en-US` is also supported. The hook connects the editor to the current-row parser and its locale automatically.
- An explicit editor `locale` conflicting with the factory parser's locale throws. Prefer configuring locale once on the parser.
- Empty input becomes `null`. Finite numbers and null remain typed; malformed numeric text is rejected. By default the parser rejects currency symbols, percent symbols, and exponent strings.
- Invalid final Enter/Tab/click-away edits are canceled. The editor retains raw drafts for bulk editing; each destination applies its own parser.
- Display formatting does not round stored values or limit editor precision. Grid labels (`localeText`), input parsing, display formatting, and browser locale are separate responsibilities.
- Without a binding parser, the editor falls back to its own locale conversion, but paste/fill still use the binding contract. Supply the factory for consistent interactions.

## Budget binding and column

### `budget-column.ts`

<!-- consumer-example: number-editor/budget-column.ts -->

```ts
import type { ColDef } from 'ag-grid-community'
import { SpreadsheetNumberEditor, createSpreadsheetNumberParser } from 'sbwb-ds-v2-aggrid'
import type { ColumnBinding } from 'sbwb-ds-v2-aggrid'

type Project = { id: string; name: string; budget: number | null }
const parseBudget = createSpreadsheetNumberParser<Project>({ locale: 'pt-BR' })
const budgetFormat = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
export const budgetBinding: ColumnBinding<Project> = {
  columnId: 'budget',
  read: (row) => row.budget,
  parse: parseBudget,
  write: (row, value) =>
    value === null || (typeof value === 'number' && Number.isFinite(value))
      ? { ...row, budget: value }
      : row,
}
export const budgetColumn: ColDef<Project> = {
  field: 'budget',
  colId: 'budget',
  editable: true,
  cellDataType: 'number',
  cellEditor: SpreadsheetNumberEditor<Project>,
  cellEditorParams: { inputAriaLabel: 'Budget editor' },
  valueFormatter: ({ value }) => (value == null ? '' : budgetFormat.format(value)),
}
```

## Values, display, and clipboard

| Input or stored value  | Result with this pt-BR configuration                   |
| ---------------------- | ------------------------------------------------------ |
| Input `12,5`           | Stores the number `12.5`; displays `12,50`.            |
| Empty input            | Stores `null`; displays an empty cell.                 |
| Input `abc` or `1,2,3` | Rejects; retains the previous stored value.            |
| Stored `1.234`         | Displays `1,23`; default copy preserves it as `1,234`. |
| Stored `12.5`          | Default copy exports `12,5`, without grouping.         |

Default copy/cut uses lossless numeric text in the factory parser locale unless `formatCell` overrides it. Matching-locale paste restores the number; a different destination locale parses according to its own grammar without guessing the source locale. Custom plain parser functions without factory metadata retain the ordinary clipboard defaults.

For en-US input, change the factory option to `locale: 'en-US'`. Choose the display formatter separately. The factory also accepts `invalidMessage` and a custom `parse` callback receiving the full row/address/source context. Custom success values must still be finite numbers or null; exceptions become ordinary parse rejections. Domain rules such as minimum budgets belong to application validation.

See [column bindings](./column-bindings.md), [Locale](./locale.md), and the [parser API](./api-reference.md#createspreadsheetnumberparser).

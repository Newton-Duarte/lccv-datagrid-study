# Locale

Configure grid translations independently of number parsing and formatted cell content. Prerequisite: [standard grid setup](./standard-grid.md).

## Rules

- `DataGrid` defaults to `AG_GRID_LOCALE_BR` from `@ag-grid-community/locale`.
- Pass `localeText` to override that default. An empty object uses AG Grid's built-in English labels; an explicit map can customize individual labels (missing entries use AG Grid's defaults).
- Recreate the grid when changing translations, for example with a React `key`. Keep rows outside the keyed grid to retain edits.
- `localeText` does not configure numeric input, currency display, or native date-picker/browser controls.
- The [numeric binding parser](./spreadsheet-number-editor.md) controls numeric input/clipboard locale; `Intl.NumberFormat` in `valueFormatter` controls display. Browser-native controls use the browser's own locale.

The official [localisation reference](https://www.ag-grid.com/react-data-grid/localisation/) describes the underlying peer behavior.

## Complete locale switch

Adapted from the working locale example. Ordinary Community editing retains the same consumer-owned row objects while the keyed grid is recreated. In immutable or form-owned workflows, keep the authoritative owner outside the keyed Spreadsheet integration too.

### `localized-grid.tsx`

<!-- consumer-example: locale/localized-grid.tsx -->

```tsx
import { useState } from 'react'
import type { ColDef } from 'ag-grid-community'
import { AG_GRID_LOCALE_BR } from '@ag-grid-community/locale'
import { DataGrid } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'

type Row = { name: string; amount: number }
const columns: ColDef<Row>[] = [
  { field: 'name', editable: true },
  { field: 'amount', editable: true },
]
const defaults: ColDef<Row> = { flex: 1, minWidth: 120, filter: true }
const english = {}
export function LocalizedGrid() {
  const [locale, setLocale] = useState<'pt-BR' | 'en-US'>('pt-BR')
  const [rows] = useState<Row[]>(() => [
    { name: 'Ada', amount: 10 },
    { name: 'Grace', amount: 20 },
  ])
  return (
    <>
      <label>
        Grid language{' '}
        <select
          value={locale}
          onChange={(event) => setLocale(event.target.value as 'pt-BR' | 'en-US')}
        >
          <option value="pt-BR">Português</option>
          <option value="en-US">English</option>
        </select>
      </label>
      <div style={{ height: 300 }}>
        <DataGrid<Row>
          key={locale}
          rowData={rows}
          columnDefs={columns}
          defaultColDef={defaults}
          localeText={locale === 'pt-BR' ? AG_GRID_LOCALE_BR : english}
          pagination
          paginationPageSize={5}
          paginationPageSizeSelector={false}
        />
      </div>
    </>
  )
}
```

Finish or cancel an active editor before changing the key if its uncommitted draft matters. Recreating a Spreadsheet integration also recreates its local selection/history; stored rows remain the responsibility of the outer data owner.

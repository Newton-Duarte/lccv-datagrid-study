# SpreadsheetCellRenderer

Customize Spreadsheet cell content while retaining selection and handles. Prerequisite: the [complete Spreadsheet setup](./spreadsheet-mode.md#complete-example).

## Rules

- `useSpreadsheet` supplies `SpreadsheetCellRenderer` for bound body cells without an effective custom renderer or renderer selector. Existing renderers, including data-type renderers, remain in charge.
- Set `cellRendererParams.renderContent` to change the content inside the standard `SpreadsheetCell` wrapper. You do not need to create a Spreadsheet connection yourself.
- `renderContent(params)` takes priority, including an intentional empty result such as `null`. Otherwise the renderer uses `valueFormatted`, then plain text (`''` for nullish values).
- Return a component if your content needs hooks; do not call hooks inside the content callback itself.
- Display content does not modify the stored value or outbound clipboard serialization.

## Project name badge

In the Project setup, replace the name column with `nameColumn` below and keep the budget column. The model matches the setup. The hook still installs its renderer and supplies the connection.

### `name-column.tsx`

<!-- consumer-example: renderer/name-column.tsx -->

```tsx
import type { ColDef } from 'ag-grid-community'
import { SpreadsheetTextEditor } from 'sbwb-ds-v2-aggrid'
import type { SpreadsheetCellRendererParams } from 'sbwb-ds-v2-aggrid'

type Project = { id: string; name: string; budget: number | null }
export const nameColumn: ColDef<Project> = {
  field: 'name',
  colId: 'name',
  editable: true,
  cellEditor: SpreadsheetTextEditor<Project>,
  cellRendererParams: {
    renderContent: ({ value }: SpreadsheetCellRendererParams<Project, string>) => (
      <span style={{ borderRadius: 12, padding: '2px 10px', background: 'var(--color-brand-100)' }}>
        {value ?? ''}
      </span>
    ),
  },
}
```

Use [Custom Renderer](./custom-renderer.md) when you need to own the whole renderer. The [API reference](./api-reference.md#spreadsheetcellrendererparams) lists the complete public parameters.

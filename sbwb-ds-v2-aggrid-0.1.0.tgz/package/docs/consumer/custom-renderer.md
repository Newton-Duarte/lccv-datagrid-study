# Custom Renderer

Own the cell renderer while preserving Spreadsheet selection and handles. Prerequisite: the [complete Spreadsheet setup](./spreadsheet-mode.md#complete-example). For content-only customization, use [renderContent](./spreadsheet-cell-renderer.md).

## Rules

- `useSpreadsheet` preserves your effective renderer/selector and supplies the hook-owned `getSpreadsheet` accessor through renderer params. Do not allocate or replace that connection.
- Wrap eligible body-cell content in `SpreadsheetCell` with its displayed `rowIndex` and column ID.
- Return plain content when row data/position/column are unavailable, or for pinned/group/footer rows and stale displayed-row identities.
- During initialization, the accessor can return null. Delegate to `SpreadsheetCellRenderer` with `renderContent` so content remains visible and the wrapper attaches when the connection is ready.
- The hook does not wrap your renderer twice. Interactive content must explicitly manage keyboard and focus ownership so controls retain native behavior.

## Complete renderer module

This adapts the working Project renderer. Copy both modules next to the Project setup; substitute `nameColumn` for its name column and keep the budget column.

### `project-cell.tsx`

<!-- consumer-example: custom-renderer/project-cell.tsx -->

```tsx
import type { ReactNode } from 'react'
import { SpreadsheetCell, SpreadsheetCellRenderer } from 'sbwb-ds-v2-aggrid'
import type { SpreadsheetCellRendererParams } from 'sbwb-ds-v2-aggrid'

export type Project = {
  id: string
  name: string
  budget: number | null
}

export function ProjectCell(params: SpreadsheetCellRendererParams<Project, string>): ReactNode {
  const content = <strong>{params.valueFormatted ?? params.value ?? ''}</strong>
  const rowIndex = params.node.rowIndex
  const columnId = params.column?.getColId()

  if (
    params.data === undefined ||
    rowIndex == null ||
    !Number.isInteger(rowIndex) ||
    rowIndex < 0 ||
    !columnId ||
    params.node.rowPinned != null ||
    params.node.group ||
    params.node.footer ||
    params.api.getDisplayedRowAtIndex(rowIndex)?.id !== params.node.id
  ) {
    return content
  }

  const spreadsheet = params.getSpreadsheet?.()
  if (!spreadsheet) {
    return <SpreadsheetCellRenderer {...params} renderContent={() => content} />
  }

  return (
    <SpreadsheetCell spreadsheet={spreadsheet} position={{ rowIndex, columnId }}>
      {content}
    </SpreadsheetCell>
  )
}
```

### `name-column.ts`

<!-- consumer-example: custom-renderer/name-column.ts -->

```ts
import type { ColDef } from 'ag-grid-community'
import { SpreadsheetTextEditor } from 'sbwb-ds-v2-aggrid'
import { ProjectCell } from './project-cell.tsx'
import type { Project } from './project-cell.tsx'

export const nameColumn: ColDef<Project> = {
  field: 'name',
  colId: 'name',
  editable: true,
  cellRenderer: ProjectCell,
  cellEditor: SpreadsheetTextEditor<Project>,
}
```

Do not retain a displayed row index as a domain row ID: sorting and filtering can change positions. Reads/writes still belong to [column bindings](./column-bindings.md). See [SpreadsheetCell](./api-reference.md#spreadsheetcell) for its exact props.

# Column bindings

A `ColumnBinding<TData>` tells Spreadsheet operations how to read, parse, and immutably update one column. Start with the [complete Spreadsheet setup](./spreadsheet-mode.md#complete-example). Ordinary [column definitions](./column-definitions.md) still control presentation and editability.

## Contract

| Member                                                 | Purpose                                                                                                                                                                                                                                          |
| ------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `columnId: string`                                     | Matches the displayed grid column ID (`colId`).                                                                                                                                                                                                  |
| `read(row): unknown`                                   | Reads its authoritative stored value.                                                                                                                                                                                                            |
| `write?(row, value): TData`                            | Returns the next row; keep the input row immutable.                                                                                                                                                                                              |
| `writable?: boolean`                                   | Allows a custom adapter to own writes without a binding writer when set to `true`. With the immutable adapter, provide a writer. `false` does not disable an existing writer; use grid `editable: false` or omit the writer for read-only cells. |
| `parse?({ input, row, address, source }): ParseResult` | Converts raw clipboard/fill/bulk input and explicit raw operations; return `{ ok: false, message? }` to reject.                                                                                                                                  |
| `codec?: ValueCodec`                                   | Clones, compares, and measures values for safe snapshots and history.                                                                                                                                                                            |

The operation also respects grid `editable`. A column needs a writer (or `writable: true` with a capable custom adapter) and effective grid editability. Without a writer the immutable adapter cannot update it. Keep the array and its functions immutable and stable for the hook's lifetime; remount when changing the mapping.

Raw candidates run through `parse` when supplied. Clear candidates pass an empty string to the parser; without a parser they become `null`. Already-parsed candidates bypass parsing. Ordinary inline `cellEditRequest` events use that already-parsed path: `binding.parse` is not invoked again by the runner. The supplied number editor calls its binding parser before emitting a value. Custom editors must produce the stored value they intend to commit; apply any required text normalization in the editor or writer as well as the raw-input parser. Do not assume a parser validates every possible programmatic write: writers must preserve the application's stored-value invariants. `valueParser`/`valueSetter` on a `ColDef` are not used as binding functions during replay.

## A column and its binding

Use the following budget column and binding in the Project setup. Both use `budget` as their ID. The editor and display configuration belong to the column; numeric input conversion and immutable storage belong to the binding. Keep the existing name column/binding if it should remain editable.

### `budget-column.ts`

<!-- consumer-example: column-bindings/budget-column.ts -->

```ts
import type { ColDef } from 'ag-grid-community'
import { SpreadsheetNumberEditor, createSpreadsheetNumberParser } from 'sbwb-ds-v2-aggrid'
import type { ColumnBinding } from 'sbwb-ds-v2-aggrid'

export type Project = { id: string; name: string; budget: number | null }
export const budgetColumn: ColDef<Project> = {
  field: 'budget',
  colId: 'budget',
  editable: true,
  cellDataType: 'number',
  cellEditor: SpreadsheetNumberEditor<Project>,
}
export const budgetBinding: ColumnBinding<Project> = {
  columnId: 'budget',
  read: (row) => row.budget,
  parse: createSpreadsheetNumberParser<Project>(),
  write: (row, value) =>
    value === null || (typeof value === 'number' && Number.isFinite(value))
      ? { ...row, budget: value }
      : row,
}
```

## Object values and codecs

The default codec supports primitives, `null`, `undefined`, and `Date`. Supply a codec for other objects; cloning must preserve the value without shared mutable snapshots, equality must compare its meaning, and `measure` must return a finite non-negative size. This object-value codec can be assigned to a binding for a `{ label: string } | null` cell; adapt its reader, writer, and parser to that row model.

### `label-codec.ts`

<!-- consumer-example: label-codec/label-codec.ts -->

```ts
import type { ValueCodec } from 'sbwb-ds-v2-aggrid'
type Label = { label: string } | null
function asLabel(value: unknown): Label {
  if (value === null) return null
  if (
    typeof value === 'object' &&
    value !== null &&
    'label' in value &&
    typeof value.label === 'string'
  )
    return { label: value.label }
  throw new TypeError('Expected a label object or null')
}
export const labelCodec: ValueCodec = {
  clone: asLabel,
  equals: (left, right) => asLabel(left)?.label === asLabel(right)?.label,
  measure: (value) => new TextEncoder().encode(asLabel(value)?.label ?? '').byteLength,
}
```

Business constraints belong to your application. A parser can reject malformed input; form validation can accept a nullable draft while requiring a positive budget before submission. See [numeric editing](./spreadsheet-number-editor.md) and [React Hook Form](./react-hook-form.md). The [API reference](./api-reference.md#columnbinding) contains the exact types.

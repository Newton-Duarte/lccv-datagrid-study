# sbwb-ds-v2-aggrid

React 18 or 19 `DataGrid` component library backed by AG Grid Community Edition and styled with the SUBWEB design tokens.

## Installation

```bash
npm install sbwb-ds-v2-aggrid @ag-grid-community/locale ag-grid-community ag-grid-react
```

The package keeps React, React DOM, `ag-grid-community`, and `ag-grid-react` as peer dependencies so the consuming application controls compatible runtime versions.

Requires React 18 or 19 with a matching React DOM version. Use the
corresponding major versions of `@types/react` and `@types/react-dom` in TypeScript
applications. The library is developed with React 19 types.

To check the packed package against React 18.0.0 and 19.0.0, including consumer
type checking and server rendering, run:

```bash
npm run build
node scripts/verify-spreadsheet-peers.mjs --ag-grid-version 36.2.0
```

Pass `--react-version <version>` to check a specific React 18 or 19 release.

## Usage

```tsx
import { DataGrid } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'

const columns = [{ field: 'name' }, { field: 'status' }]
const rows = [{ name: 'Ada', status: 'Active' }]

export function Users() {
  return (
    <div style={{ height: '24rem' }}>
      <DataGrid rowData={rows} columnDefs={columns} />
    </div>
  )
}
```

`DataGrid` fills its parent. The consuming application must provide a non-zero height on the component or one of its ancestors.

The component accepts AG Grid's `AgGridReactProps` and an optional `className`, so standard Community configuration and event handlers can be passed directly.

The default grid locale is Brazilian Portuguese (`pt-BR`). Pass AG Grid's `localeText` prop to override the default for a specific grid. When changing the locale at runtime, recreate the grid, for example by changing its React key. Keep row data in an outer owner to preserve edits. Native browser controls, such as the date picker, use the browser's locale instead.

## Opt-in spreadsheet module

The spreadsheet layer is a consumer-owned adapter on top of the Community grid. It supports body/client-side row data only, stable `getRowId` values, and explicit `ColumnBinding` readers/writers. Add a parser when raw clipboard, fill, or bulk input needs conversion, and add a `ValueCodec` for non-primitive values. AG Grid `valueParser` and `valueSetter` callbacks are not automatically replayable by this layer.

The adapter is synchronous: keep the authoritative snapshot in a consumer-owned ref and use React only for the projection and acknowledgment. The projection may be updated once per published batch, but the package does not promise an exactly-one-render result.

Keep `data` and the registered `bindings` array immutable and identity-stable for the lifetime of a `useSpreadsheet` hook. Memoize the adapter and binding registration (including each reader, writer, parser, and codec); changing the source or mapping requires remounting the spreadsheet integration with a new `key`. The hook rejects adapter or binding ownership changes instead of mixing clipboard reads with stale mutation and history owners. Ordinary `rowData`/projection/version updates, column editability configuration, and consumer callback updates remain supported.

```tsx
import { useState } from 'react'
import type { ColDef } from 'ag-grid-community'
import {
  DataGrid,
  SpreadsheetTextEditor,
  SpreadsheetNumberEditor,
  createImmutableDataAdapter,
  createSpreadsheetNumberParser,
  useSpreadsheet,
} from 'sbwb-ds-v2-aggrid'
import type { ColumnBinding, DataSnapshot } from 'sbwb-ds-v2-aggrid'
import 'sbwb-ds-v2-aggrid/styles/theme.css'

type Row = { id: string; name: string; amount: number | null }
const bindings: readonly ColumnBinding<Row>[] = [
  {
    columnId: 'name',
    read: (row) => row.name,
    parse: ({ input }) => ({ ok: true, value: String(input ?? '') }),
    write: (row, value) => ({ ...row, name: String(value ?? '') }),
  },
  {
    columnId: 'amount',
    read: (row) => row.amount,
    parse: createSpreadsheetNumberParser<Row>(), // pt-BR; use { locale: 'en-US' } for dot decimals
    write: (row, value) =>
      value === null || (typeof value === 'number' && Number.isFinite(value))
        ? { ...row, amount: value }
        : row,
  },
]
const columnDefs: ColDef<Row>[] = [
  { field: 'name', editable: true, cellEditor: SpreadsheetTextEditor<Row> },
  { field: 'amount', editable: true, cellEditor: SpreadsheetNumberEditor<Row> },
]

function SpreadsheetExample() {
  const [initial] = useState<DataSnapshot<Row>>(() => ({
    version: 0,
    rows: [{ id: 'row-1', name: 'Ada', amount: 42 }],
  }))
  const [projection, setProjection] = useState(initial)
  const [data] = useState(() => {
    let snapshot = initial
    return createImmutableDataAdapter<Row>({
      bindings,
      getRowId: (row) => row.id,
      getSnapshot: () => snapshot,
      publish: (next) => {
        snapshot = next
        setProjection(next)
      },
    })
  })
  const spreadsheet = useSpreadsheet({
    data,
    bindings,
    gridProps: {
      rowData: projection.rows.map((row) => ({ ...row })),
      columnDefs,
      getRowId: ({ data }) => data.id,
    },
  })
  return (
    <div ref={spreadsheet.hostRef} style={{ height: '24rem' }}>
      <DataGrid<Row> {...spreadsheet.gridProps} />
    </div>
  )
}
```

The hook supplies `SpreadsheetCellRenderer` and its stable connection for bound columns without
an effective consumer renderer or selector. It wraps content in `SpreadsheetCell` for selection
and handles. A bare `DataGrid` remains the ordinary grid. `SpreadsheetTextEditor` and
`SpreadsheetNumberEditor` are optional editors with registered raw drafts for bulk editing.
Keep the adapter and bindings stable; row projections may change normally.

The numeric parser factory accepts `locale` (`pt-BR` by default or `en-US`), an optional application
`parse` callback, and `invalidMessage`. It preserves finite numbers and null, validates localized
grouping, and rejects default currency/percent symbols and exponent strings. Custom parsers receive
the row, address, input and source; successful values must still be finite numbers or null.
The number editor obtains the locale and current-row parser from the binding, keeps raw drafts,
and cancels invalid final Enter/Tab/click-away edits. A conflicting editor `locale` is an error.
Without a binding parser, editor conversion falls back to its locale; paste/fill still follow the
binding contract. Numeric examples should supply the factory for consistent behavior.

Default copy/cut and row/range exports use lossless, ungrouped numeric text in the factory locale:
12.5 becomes `12,5` and 1.234 becomes `1,234` in pt-BR. Matching-locale paste restores those values;
different-locale destinations apply their own parser without source-locale guessing. Explicit
`formatCell` always wins. Plain custom parsers without factory metadata keep existing clipboard
defaults. Input locale is separate from `localeText`, display `valueFormatter`, and currency formatting.

Use `cellRendererParams.renderContent` for a noninteractive badge or other React content inside the
standard wrapper. Its result takes precedence even when intentionally empty; otherwise the renderer
uses `valueFormatted`, then plain text with null/undefined empty. Neither rendering path changes
stored values or clipboard formatting. Return components when content needs hooks. Fully custom
renderers/selectors remain in charge and receive `getSpreadsheet`; wrap their content explicitly in
`SpreadsheetCell` when handles are wanted. Custom editors keep their own behavior and can register
raw drafts through the supplied `registerEditor`. Infrastructure collisions are rejected.

The root exports `SpreadsheetNumberEditorParams`, `SpreadsheetNumberEditorProps<TData>`,
`SpreadsheetCellRendererParams<TData, TValue>`, `SpreadsheetNumberLocale`,
`SpreadsheetNumberParser<TData>`, and `SpreadsheetNumberParserOptions<TData>` alongside the existing
text editor, cell, hook, and data types. See the homepage Reference for complete customization examples.

Normal operations use partial acceptance: writable cells can commit while readonly, missing, or unparsable candidates are returned in `rejected`. Paste and fill operate from the active range. `Ctrl+Enter` bulk editing uses the union of selected ranges, deduplicated once; that supported bulk path requires `SpreadsheetTextEditor`, `SpreadsheetNumberEditor`, or an equivalent editor bridge to register its raw draft through `cellEditorParams.registerEditor`. An equivalent bridge should also provide the optional positive target predicate `ownsTarget(target)`, normally by comparing the event target with its input ref (or its own editor root). Registrations without that capability fail closed to ordinary native behavior rather than claiming another input; this is an additive migration step, not a breaking type change. Native Enter, text editing shortcuts, IME input, and editor-owned clipboard shortcuts remain native. The bridge is opt-in and does not take ownership of arbitrary AG Grid editors.

Cut is a confirmed write: clipboard export must succeed before the clear operation is committed. A denied or unavailable clipboard leaves the data unchanged. History stores accepted deltas rather than attempted candidates, is bounded by 100 commands and 5 MiB by default, and is cleared by sorting, filtering, schema/order changes, grid destruction, or an external authoritative reset.

The module does not evaluate formulas, add AG Grid Enterprise features, or support server-side/infinite row models. It also does not install React Hook Form (RHF). An RHF consumer adapter should resolve stable domain IDs and column IDs through immutable maps, then perform the accepted form writes synchronously inside its `SpreadsheetDataAdapter.commitChanges` implementation—not from the `onResult` notification. For each accepted change, call targeted `setValue("rowsById.<id>.<column>", change.newValue, { shouldDirty: true, shouldValidate: false })`; preserve offscreen fields and trigger deferred validation for the changed domain IDs after the batch. Keep the adapter's version and operation acknowledgment explicit and pass that acknowledgment back to `useSpreadsheet`; do not rebuild the full form from the virtualized grid projection. This guidance is documentation-only and does not guarantee one React render.

The homepage includes optional [React Hook Form integration guide](#react-hook-form) with a step-by-step Edit → Save / Cancel walkthrough and a shorter autosave variation using the same form connection. The complete sources expose explicit column editors, bindings, and named callbacks that update individual form fields. Saving only valid snapshots is an example application policy. They install `react-hook-form@^7.92.0` as an application dependency, keep persistence consumer-owned, and use a simulated request that you replace with your own save function.

## Theme Customization

The library uses AG Grid's modern Theming API with Quartz defaults and six token-backed foundation parameters: accent, background, chrome background, foreground, invalid color, and font family. Quartz retains its default controls, checkbox marks, focus treatment, borders, spacing, and 14px font size. The theme and package CSS are included automatically with `DataGrid`.

You don't need a separate CSS import when using `DataGrid`. If your application loads the stylesheet separately, import only `theme.css`; it already includes the design tokens:

```css
@import 'sbwb-ds-v2-aggrid/styles/theme.css';
```

Import `sbwb-ds-v2-aggrid/styles/tokens.css` on its own only when you need the raw tokens without the grid layout styles.

Override the mapped design-system tokens in an application scope when the whole area should use a different brand palette:

```css
.application-theme {
  --color-sky-500: #7c3aed;
  --color-gray-50: #faf5ff;
  --color-stone-900: #2e1065;
}
```

For a single grid, override AG Grid custom properties with the optional `className`. The combined selector keeps the override scoped to that grid:

```css
.customer-grid.sbwb-data-grid {
  --ag-header-background-color: #f5f3ff;
  --ag-row-hover-color: #ede9fe;
}
```

The `theme` prop can also replace the shared theme with another AG Grid theme or an application-specific `themeQuartz.withParams()` result:

```tsx
import { themeQuartz } from 'ag-grid-community'
import { DataGrid } from 'sbwb-ds-v2-aggrid'

const customerTheme = themeQuartz.withParams({
  accentColor: 'var(--color-violet-600)',
  headerBackgroundColor: 'var(--color-violet-50)',
  menuTextColor: 'var(--color-stone-900)',
})

<DataGrid theme={customerTheme} className="customer-grid" rowData={rows} columnDefs={columns} />
```

The package's default theme maps only foundation colors and font family to design-system tokens. Quartz derives the remaining component styles; AG Grid custom properties can be overridden from application CSS, while the `theme` prop is available when a complete theme object is needed.

## Development Scripts

- `npm run dev`: start the local Vite sandbox.
- `npm run build`: create ESM, CommonJS, declaration, and CSS outputs in `dist/`.
- `npm run test`: run the Vitest suite once.
- `npm run test:e2e`: run the isolated Chromium browser suite with one worker and no retries.
- `npm run test:e2e:headed`: run the same suite with a visible browser (requires a local display).
- `npx playwright install chromium`: install the development-only Playwright Chromium binary when it is not already available; no runtime or global install is required.
- `npm run test:watch`: run Vitest in watch mode.
- `npm run lint`: run ESLint's flat configuration.
- `npm run format`: format repository files with Prettier.
- `npm run format:check`: check formatting without changing files.
- `npm run preview`: preview the Vite build.

Browser tests start each case with a fresh Playwright page/context and the
configured local Vite server on `127.0.0.1:5187`; the server is never reused.
The specs use trusted mouse/keyboard input and the actual sandbox. On a Linux
machine without a desktop display, run `xvfb-run -a npm run test:e2e` (or the
headed command) rather than changing the test setup. `test:e2e` is still
headed at the browser level because the native-scrollbar checks require a
real rendered surface; `test:e2e:headed` is for observing that same run on a
visible display.

The configured reporter is Playwright's `list` reporter. Results and failure
screenshots/traces are written under `test-results/`; there is no HTML report
configured. Use `npm run test:e2e -- --reporter=line` for a compact log,
`npm run test:e2e -- --trace on` to retain a trace for every test, and
`npx playwright show-trace test-results/<test>/trace.zip` to inspect a trace.
The autoscroll maximum is configurable through
`useSpreadsheet({ viewport: { maxSpeedPxPerSecond: 600 } })`; set it to `0`
to disable autoscroll. The default is 600 CSS pixels/second per axis.

## Package Outputs

- `dist/index.es.js`: ESM entry.
- `dist/index.cjs.js`: CommonJS entry.
- `dist/index.cjs`: Node-compatible CommonJS entry used by `require`.
- `dist/index.d.ts`: generated public declarations.
- `dist/theme.css`: design tokens and scoped grid layout styles; the Quartz theme comes from `themeQuartz.withParams()`.
- `dist/tokens.css`: design-system custom properties.
